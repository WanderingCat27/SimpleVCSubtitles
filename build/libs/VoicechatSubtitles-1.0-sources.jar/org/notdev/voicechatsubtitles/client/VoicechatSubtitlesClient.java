package org.notdev.voicechatsubtitles.client;

import org.python.util.PythonInterpreter;
import net.fabricmc.api.ClientModInitializer;

import java.util.List;

public class VoicechatSubtitlesClient implements ClientModInitializer {
    /**
     * Runs the mod initializer on the client environment.
     */
    @Override
    public void onInitializeClient() {

    }

    public static void main(String[] args) throws Exception {
        try(PythonInterpreter pyInterp = new PythonInterpreter()) {
            pyInterp.exec("print('Hello Python World!')");
        }
    }
}
