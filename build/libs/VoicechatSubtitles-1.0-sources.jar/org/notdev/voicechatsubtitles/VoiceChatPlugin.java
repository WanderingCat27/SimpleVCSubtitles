package org.notdev.voicechatsubtitles;

import de.maxhenkel.voicechat.VoicechatClient;
import de.maxhenkel.voicechat.api.VoicechatApi;
import de.maxhenkel.voicechat.api.VoicechatPlugin;
import de.maxhenkel.voicechat.api.events.ClientReceiveSoundEvent;
import de.maxhenkel.voicechat.api.events.EventRegistration;
import de.maxhenkel.voicechat.api.mp3.Mp3Encoder;
import de.maxhenkel.voicechat.plugins.impl.mp3.Mp3EncoderImpl;
import de.maxhenkel.voicechat.voice.client.SoundManager;

import javax.sound.sampled.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

public class VoiceChatPlugin implements VoicechatPlugin {


    File outputFile;

    final int max = 960 * 200;
    short[] buffer = new short[960 * 202];
    AudioFormat stereoFormat = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, SoundManager.SAMPLE_RATE /2, 16, 2, 4, SoundManager.FRAME_SIZE, false);


    /**
     * @return the unique ID for this voice chat plugin
     */
    @Override
    public String getPluginId() {
        return VoicechatSubtitles.MOD_ID;
    }

    /**
     * Called when the voice chat initializes the plugin.
     *
     * @param api the voice chat API
     */
    @Override
    public void initialize(VoicechatApi api) {
        outputFile = new File("test.mp3");

    }

    /**
     * Called once by the voice chat to register all events.
     *
     * @param registration the event registration
     */
    @Override
    public void registerEvents(EventRegistration registration) {
        registration.registerEvent(ClientReceiveSoundEvent.EntitySound.class, this::receiveSound);
    }
int index = 0;
    private void receiveSound(ClientReceiveSoundEvent clientReceiveSoundEvent) {
        if(index >= max) {
            appendShortArrayToWav(outputFile.getPath(), buffer);
            buffer = new short[960 * 202];
            index = 0;
        }
        System.out.println("recieved sound: len: " + clientReceiveSoundEvent.getRawAudio().length);
        System.out.println("Raw Audio " + clientReceiveSoundEvent.getRawAudio());
            for(short sh : clientReceiveSoundEvent.getRawAudio())
                buffer[index++] = sh;
    }

    public void appendShortArrayToWav(String wavFilePath, short[] newAudioData) {

        int bufferIndex = 0;
        try {
            FileOutputStream outStream = new FileOutputStream(outputFile.getPath(), true);

            Mp3Encoder encoder = Mp3EncoderImpl.createEncoder(stereoFormat, 120, VoicechatClient.CLIENT_CONFIG.recordingQuality.get(), outStream);
            encoder.encode(newAudioData);

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
